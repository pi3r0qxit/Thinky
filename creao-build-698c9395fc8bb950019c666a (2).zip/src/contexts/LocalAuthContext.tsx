import { createContext, useContext, useState, useEffect } from "react";

interface User {
	id: string;
	email: string;
	name: string;
	isPremium: boolean;
	createdAt: string;
}

interface LocalAuthContextValue {
	user: User | null;
	isAuthenticated: boolean;
	isLoading: boolean;
	login: (email: string, password: string) => Promise<boolean>;
	register: (email: string, password: string, name: string) => Promise<boolean>;
	logout: () => void;
}

const LocalAuthContext = createContext<LocalAuthContextValue | undefined>(undefined);

// Simple hash function for demo purposes (in production, use proper password hashing on backend)
async function simpleHash(text: string): Promise<string> {
	const encoder = new TextEncoder();
	const data = encoder.encode(text);
	const hashBuffer = await crypto.subtle.digest("SHA-256", data);
	const hashArray = Array.from(new Uint8Array(hashBuffer));
	return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function LocalAuthProvider({ children }: { children: React.ReactNode }) {
	const [user, setUser] = useState<User | null>(null);
	const [isLoading, setIsLoading] = useState(true);

	useEffect(() => {
		// Check for existing session
		const storedUser = localStorage.getItem("thinky_user");
		if (storedUser) {
			try {
				setUser(JSON.parse(storedUser));
			} catch {
				localStorage.removeItem("thinky_user");
			}
		}
		setIsLoading(false);
	}, []);

	const register = async (email: string, password: string, name: string): Promise<boolean> => {
		try {
			// Get existing users
			const usersJson = localStorage.getItem("thinky_users");
			const users: Record<string, { passwordHash: string; user: User }> = usersJson
				? JSON.parse(usersJson)
				: {};

			// Check if user already exists
			if (users[email]) {
				return false;
			}

			// Create new user
			const passwordHash = await simpleHash(password);
			const newUser: User = {
				id: crypto.randomUUID(),
				email,
				name,
				isPremium: false,
				createdAt: new Date().toISOString(),
			};

			users[email] = { passwordHash, user: newUser };

			// Save to localStorage
			localStorage.setItem("thinky_users", JSON.stringify(users));
			localStorage.setItem("thinky_user", JSON.stringify(newUser));

			setUser(newUser);
			return true;
		} catch (error) {
			console.error("Registration error:", error);
			return false;
		}
	};

	const login = async (email: string, password: string): Promise<boolean> => {
		try {
			// Get existing users
			const usersJson = localStorage.getItem("thinky_users");
			if (!usersJson) return false;

			const users: Record<string, { passwordHash: string; user: User }> = JSON.parse(usersJson);
			const userRecord = users[email];

			if (!userRecord) return false;

			// Verify password
			const passwordHash = await simpleHash(password);
			if (passwordHash !== userRecord.passwordHash) return false;

			// Set user session
			localStorage.setItem("thinky_user", JSON.stringify(userRecord.user));
			setUser(userRecord.user);
			return true;
		} catch (error) {
			console.error("Login error:", error);
			return false;
		}
	};

	const logout = () => {
		localStorage.removeItem("thinky_user");
		setUser(null);
	};

	return (
		<LocalAuthContext.Provider
			value={{
				user,
				isAuthenticated: !!user,
				isLoading,
				login,
				register,
				logout,
			}}
		>
			{children}
		</LocalAuthContext.Provider>
	);
}

export function useLocalAuth() {
	const context = useContext(LocalAuthContext);
	if (!context) {
		throw new Error("useLocalAuth must be used within LocalAuthProvider");
	}
	return context;
}

// Helper to get current user ID for database operations
export function getLocalUserId(): string | null {
	const storedUser = localStorage.getItem("thinky_user");
	if (!storedUser) return null;

	try {
		const user = JSON.parse(storedUser);
		return user.id;
	} catch {
		return null;
	}
}
