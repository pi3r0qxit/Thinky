import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getLocalUserId } from "@/contexts/LocalAuthContext";
import { DeckORM, type DeckModel } from "@/sdk/database/orm/orm_deck";
import { FlashcardORM, type FlashcardModel } from "@/sdk/database/orm/orm_flashcard";
import { UsageTrackingORM, type UsageTrackingModel } from "@/sdk/database/orm/orm_usage_tracking";
import { FilterBuilder, SortBuilder, CreateValue } from "@/sdk/database/orm/client";
import { DataType, Direction, SimpleSelector, MultiSelector } from "@/sdk/database/orm/common";

// Removed daily limits - everything is now free!

// Get today's date in YYYY-MM-DD format
function getTodayDate(): string {
	const today = new Date();
	return today.toISOString().split("T")[0];
}

export function useDecks() {
	return useQuery({
		queryKey: ["decks"],
		queryFn: async () => {
			const userId = getLocalUserId();
			if (!userId) return [];

			const deckORM = DeckORM.getInstance();
			const filter = new FilterBuilder()
				.equal("user_id", CreateValue(DataType.string, userId))
				.build();
			const sort = new SortBuilder()
				.add("update_time", Direction.descending)
				.build();

			const [decks] = await deckORM.listDeck(filter, sort);
			return decks;
		},
	});
}

export function useFlashcards(deckId: string | null) {
	return useQuery({
		queryKey: ["flashcards", deckId],
		queryFn: async () => {
			if (!deckId) {
				console.log("⚠️ useFlashcards: No deckId provided");
				return [];
			}

			console.log("🔍 useFlashcards: Querying flashcards for deck:", deckId);

			const flashcardORM = FlashcardORM.getInstance();
			const filter = new FilterBuilder()
				.equal("deck_id", CreateValue(DataType.string, deckId))
				.build();
			const sort = new SortBuilder()
				.add("position", Direction.ascending)
				.build();

			const [flashcards] = await flashcardORM.listFlashcard(filter, sort);
			console.log(`📚 useFlashcards: Found ${flashcards.length} flashcards for deck ${deckId}`, flashcards);
			return flashcards;
		},
		enabled: !!deckId,
	});
}

export function useUsageTracking() {
	return useQuery({
		queryKey: ["usage", getTodayDate()],
		queryFn: async () => {
			const userId = getLocalUserId();
			if (!userId) return null;

			const today = getTodayDate();
			const usageORM = UsageTrackingORM.getInstance();

			const filter = {
				simples: [],
				multiples: [
					{
						symbol: MultiSelector.and,
						field: undefined,
						value: [
							{
								symbol: SimpleSelector.equal,
								field: "user_id",
								value: CreateValue(DataType.string, userId),
							},
							{
								symbol: SimpleSelector.equal,
								field: "date",
								value: CreateValue(DataType.string, today),
							},
						],
					},
				],
				groups: [],
				unwinds: [],
			};

			const [records] = await usageORM.listUsageTracking(filter);
			return records[0] || null;
		},
	});
}

export function useCreateDeck() {
	const queryClient = useQueryClient();

	return useMutation({
		mutationFn: async (name: string) => {
			const userId = getLocalUserId();
			console.log("🆕 useCreateDeck: Creating deck", { name, userId });

			if (!userId) {
				console.error("❌ No user ID found - user might not be authenticated");
				throw new Error("User not authenticated");
			}

			const deckORM = DeckORM.getInstance();
			const deckData = {
				name,
				user_id: userId,
			} as DeckModel;

			console.log("💾 Inserting deck:", deckData);
			const [newDeck] = await deckORM.insertDeck([deckData]);
			console.log("✅ Deck created successfully:", newDeck);
			return newDeck;
		},
		onSuccess: (newDeck) => {
			console.log("🎉 Deck creation success, invalidating queries", newDeck);
			queryClient.invalidateQueries({ queryKey: ["decks"] });
		},
		onError: (error) => {
			console.error("❌ Deck creation failed:", error);
		},
	});
}

export function useUpdateDeck() {
	const queryClient = useQueryClient();

	return useMutation({
		mutationFn: async ({ id, name }: { id: string; name: string }) => {
			const deckORM = DeckORM.getInstance();
			const decks = await deckORM.getDeckByIDs([id]);
			if (decks.length === 0) throw new Error("Deck not found");

			const updated = { ...decks[0], name };
			await deckORM.setDeckById(id, updated);
			return updated;
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["decks"] });
		},
	});
}

export function useDeleteDeck() {
	const queryClient = useQueryClient();

	return useMutation({
		mutationFn: async (deckId: string) => {
			// Delete flashcards first
			const flashcardORM = FlashcardORM.getInstance();
			const filter = new FilterBuilder()
				.equal("deck_id", CreateValue(DataType.string, deckId))
				.build();
			const [flashcards] = await flashcardORM.listFlashcard(filter);

			if (flashcards.length > 0) {
				await flashcardORM.deleteFlashcardByIDs(flashcards.map((f) => f.id));
			}

			// Delete deck
			const deckORM = DeckORM.getInstance();
			await deckORM.deleteDeckByIDs([deckId]);
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["decks"] });
		},
	});
}

export function useCreateFlashcards() {
	const queryClient = useQueryClient();

	return useMutation({
		mutationFn: async ({
			deckId,
			flashcards,
		}: {
			deckId: string;
			flashcards: Array<{ question: string; answer: string }>;
		}) => {
			console.log("🔄 useCreateFlashcards: Starting flashcard creation", {
				deckId,
				flashcardCount: flashcards.length,
				flashcards,
			});

			const flashcardORM = FlashcardORM.getInstance();

			// Get current max position
			const filter = new FilterBuilder()
				.equal("deck_id", CreateValue(DataType.string, deckId))
				.build();

			console.log("📊 Querying existing flashcards for deck:", deckId);
			const [existing] = await flashcardORM.listFlashcard(filter);
			console.log("📊 Found existing flashcards:", existing.length);

			const startPosition = existing.length;

			const newFlashcards = flashcards.map((fc, index) => ({
				deck_id: deckId,
				question: fc.question,
				answer: fc.answer,
				position: startPosition + index,
			})) as FlashcardModel[];

			console.log("💾 Attempting to insert flashcards:", newFlashcards);

			try {
				const inserted = await flashcardORM.insertFlashcard(newFlashcards);
				console.log("✅ Successfully inserted flashcards:", inserted);

				// Update usage tracking ONLY after successful insertion
				console.log("📈 Updating usage count by:", flashcards.length);
				await incrementUsageCount(flashcards.length);

				return inserted;
			} catch (error) {
				console.error("❌ Failed to insert flashcards:", error);
				throw error;
			}
		},
		onSuccess: (inserted, variables) => {
			console.log("🎉 onSuccess callback - invalidating queries", {
				insertedCount: inserted.length,
				deckId: variables.deckId,
			});
			queryClient.invalidateQueries({ queryKey: ["flashcards", variables.deckId] });
			queryClient.invalidateQueries({ queryKey: ["usage"] });
			queryClient.invalidateQueries({ queryKey: ["decks"] });
		},
		onError: (error) => {
			console.error("❌ onError callback:", error);
		},
	});
}

async function incrementUsageCount(count: number) {
	const userId = getLocalUserId();
	if (!userId) return;

	const today = getTodayDate();
	const usageORM = UsageTrackingORM.getInstance();

	const filter = {
		simples: [],
		multiples: [
			{
				symbol: MultiSelector.and,
				field: undefined,
				value: [
					{
						symbol: SimpleSelector.equal,
						field: "user_id",
						value: CreateValue(DataType.string, userId),
					},
					{
						symbol: SimpleSelector.equal,
						field: "date",
						value: CreateValue(DataType.string, today),
					},
				],
			},
		],
		groups: [],
		unwinds: [],
	};

	const [records] = await usageORM.listUsageTracking(filter);

	if (records.length > 0) {
		const updated = {
			...records[0],
			generation_count: records[0].generation_count + count,
		};
		await usageORM.setUsageTrackingById(records[0].id, updated);
	} else {
		await usageORM.insertUsageTracking([
			{
				user_id: userId,
				date: today,
				generation_count: count,
			} as UsageTrackingModel,
		]);
	}
}

export function useUsageStats(isPremium: boolean) {
	const { data: usage } = useUsageTracking();

	const generatedToday = usage?.generation_count || 0;
	// Everything is free now - no limits!
	const remainingToday = Infinity;
	const canGenerate = true;

	return {
		generatedToday,
		remainingToday,
		canGenerate,
		dailyLimit: Infinity,
	};
}
