import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocalAuth } from "@/contexts/LocalAuthContext";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

interface LoginFormProps {
	onSwitchToRegister: () => void;
}

export function LoginForm({ onSwitchToRegister }: LoginFormProps) {
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const { login } = useLocalAuth();

	const handleSubmit = async (e: React.FormEvent) => {
		e.preventDefault();

		if (!email || !password) {
			toast.error("Please fill in all fields");
			return;
		}

		setIsLoading(true);

		const success = await login(email, password);

		if (success) {
			toast.success("Welcome back!");
		} else {
			toast.error("Invalid email or password");
		}

		setIsLoading(false);
	};

	return (
		<Card className="w-full max-w-md">
			<CardHeader>
				<CardTitle>Welcome Back</CardTitle>
				<CardDescription>Sign in to your Thinky account</CardDescription>
			</CardHeader>
			<CardContent>
				<form onSubmit={handleSubmit} className="space-y-4">
					<div>
						<Label htmlFor="email">Email</Label>
						<Input
							id="email"
							type="email"
							placeholder="you@example.com"
							value={email}
							onChange={(e) => setEmail(e.target.value)}
							disabled={isLoading}
						/>
					</div>

					<div>
						<Label htmlFor="password">Password</Label>
						<Input
							id="password"
							type="password"
							placeholder="••••••••"
							value={password}
							onChange={(e) => setPassword(e.target.value)}
							disabled={isLoading}
						/>
					</div>

					<Button type="submit" className="w-full" disabled={isLoading}>
						{isLoading ? (
							<>
								<Loader2 className="w-4 h-4 mr-2 animate-spin" />
								Signing in...
							</>
						) : (
							"Sign In"
						)}
					</Button>

					<div className="text-center text-sm">
						<span className="text-muted-foreground">Don't have an account? </span>
						<Button
							type="button"
							variant="link"
							className="p-0 h-auto"
							onClick={onSwitchToRegister}
						>
							Create one
						</Button>
					</div>
				</form>
			</CardContent>
		</Card>
	);
}
