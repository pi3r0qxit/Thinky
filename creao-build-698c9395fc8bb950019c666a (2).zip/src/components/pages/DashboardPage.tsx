import { useDecks, useUsageStats } from "@/hooks/useAppData";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Sparkles, BookOpen, Library, Crown } from "lucide-react";
import { Badge } from "@/components/ui/badge";

type Page = "dashboard" | "generate" | "decks" | "flashcards" | "review" | "profile" | "premium";

interface DashboardPageProps {
	onNavigate: (page: Page) => void;
	onStartReview: (deckId: string) => void;
	isPremium: boolean;
}

export function DashboardPage({ onNavigate, onStartReview, isPremium }: DashboardPageProps) {
	const { data: decks = [], isLoading } = useDecks();
	const stats = useUsageStats(isPremium);

	const recentDecks = decks.slice(0, 3);

	return (
		<div className="container mx-auto px-4 py-8 max-w-6xl">
			<div className="mb-8">
				<h1 className="text-3xl font-bold mb-2">Welcome back!</h1>
				<p className="text-muted-foreground">Ready to enhance your learning today? Create unlimited flashcards, completely free!</p>
			</div>

			{/* Quick Actions */}
			<div className="grid gap-6 md:grid-cols-3 mb-8">
				<Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate("generate")}>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<Sparkles className="w-5 h-5 text-primary" />
							Generate Flashcards
						</CardTitle>
						<CardDescription>
							Upload materials or paste text to create AI-powered flashcards
						</CardDescription>
					</CardHeader>
					<CardContent>
						<Button className="w-full gap-2">
							<Sparkles className="w-4 h-4" />
							Start Generating
						</Button>
					</CardContent>
				</Card>

				<Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate("flashcards")}>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<Library className="w-5 h-5 text-primary" />
							Browse Flashcards
						</CardTitle>
						<CardDescription>
							Search and view all your flashcards in one place
						</CardDescription>
					</CardHeader>
					<CardContent>
						<Button variant="outline" className="w-full gap-2">
							<Library className="w-4 h-4" />
							View Flashcards
						</Button>
					</CardContent>
				</Card>

				<Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate("decks")}>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<BookOpen className="w-5 h-5 text-primary" />
							My Decks
						</CardTitle>
						<CardDescription>
							Review and manage your flashcard collections
						</CardDescription>
					</CardHeader>
					<CardContent>
						<Button variant="outline" className="w-full gap-2">
							<BookOpen className="w-4 h-4" />
							View All Decks
						</Button>
					</CardContent>
				</Card>
			</div>

			{/* Recent Decks */}
			<div>
				<div className="flex items-center justify-between mb-4">
					<h2 className="text-2xl font-bold">Recent Decks</h2>
					<Button variant="ghost" onClick={() => onNavigate("decks")}>
						View All
					</Button>
				</div>

				{isLoading ? (
					<div className="text-center py-12">
						<div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
						<p className="text-sm text-muted-foreground">Loading decks...</p>
					</div>
				) : recentDecks.length === 0 ? (
					<Card>
						<CardContent className="py-12 text-center">
							<BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
							<p className="text-muted-foreground mb-4">No decks yet</p>
							<Button onClick={() => onNavigate("generate")} className="gap-2">
								<Sparkles className="w-4 h-4" />
								Create Your First Deck
							</Button>
						</CardContent>
					</Card>
				) : (
					<div className="grid gap-4 md:grid-cols-3">
						{recentDecks.map((deck) => (
							<Card key={deck.id} className="hover:shadow-lg transition-shadow">
								<CardHeader>
									<CardTitle className="text-lg">{deck.name}</CardTitle>
									<CardDescription>
										Updated {new Date(parseInt(deck.update_time) * 1000).toLocaleDateString()}
									</CardDescription>
								</CardHeader>
								<CardContent>
									<Button
										variant="outline"
										className="w-full"
										onClick={() => onStartReview(deck.id)}
									>
										Start Review
									</Button>
								</CardContent>
							</Card>
						))}
					</div>
				)}
			</div>
		</div>
	);
}
