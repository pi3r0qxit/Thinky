import { useState, useMemo } from "react";
import { useDecks } from "@/hooks/useAppData";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Search, Play } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { FlashcardORM } from "@/sdk/database/orm/orm_flashcard";
import { FilterBuilder, CreateValue } from "@/sdk/database/orm/client";
import { DataType, Direction } from "@/sdk/database/orm/common";

interface AllFlashcardsPageProps {
	onStartReview: (deckId: string) => void;
}

export function AllFlashcardsPage({ onStartReview }: AllFlashcardsPageProps) {
	const { data: decks = [], isLoading: decksLoading } = useDecks();
	const [searchQuery, setSearchQuery] = useState("");

	// Fetch all flashcards in a single query instead of one per deck
	const { data: allFlashcards = [], isLoading: flashcardsLoading } = useQuery({
		queryKey: ["all-flashcards"],
		queryFn: async () => {
			const flashcardORM = FlashcardORM.getInstance();
			const flashcards = await flashcardORM.getAllFlashcard();
			return flashcards;
		},
	});

	// Group flashcards by deck
	const allFlashcardsData = useMemo(() => {
		return decks.map((deck) => {
			const flashcards = allFlashcards.filter((card) => card.deck_id === deck.id);
			return { deck, flashcards };
		});
	}, [decks, allFlashcards]);

	const totalFlashcards = allFlashcards.length;

	// Filter flashcards based on search query
	const filteredData = useMemo(() => {
		return allFlashcardsData
			.map((item) => ({
				...item,
				flashcards: item.flashcards.filter(
					(card) =>
						card.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
						card.answer.toLowerCase().includes(searchQuery.toLowerCase())
				),
			}))
			.filter((item) => item.flashcards.length > 0);
	}, [allFlashcardsData, searchQuery]);

	const isLoading = decksLoading || flashcardsLoading;

	if (isLoading) {
		return (
			<div className="flex items-center justify-center min-h-[60vh]">
				<div className="text-center">
					<div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
					<p className="text-muted-foreground">Loading flashcards...</p>
				</div>
			</div>
		);
	}

	return (
		<div className="container mx-auto px-4 py-8 max-w-6xl">
			<div className="mb-8">
				<h1 className="text-3xl font-bold mb-2">All Flashcards</h1>
				<p className="text-muted-foreground">
					Browse and search through all your flashcards ({totalFlashcards} total)
				</p>
			</div>

			{/* Search Bar */}
			<div className="mb-6">
				<div className="relative">
					<Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
					<Input
						placeholder="Search flashcards..."
						value={searchQuery}
						onChange={(e) => setSearchQuery(e.target.value)}
						className="pl-10"
					/>
				</div>
			</div>

			{totalFlashcards === 0 ? (
				<Card>
					<CardContent className="py-16 text-center">
						<BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
						<h3 className="text-xl font-semibold mb-2">No flashcards yet</h3>
						<p className="text-muted-foreground mb-6">
							Start by generating your first set of flashcards
						</p>
					</CardContent>
				</Card>
			) : (
				<Tabs defaultValue="all" className="space-y-6">
					<TabsList>
						<TabsTrigger value="all">
							All ({filteredData.reduce((sum, item) => sum + item.flashcards.length, 0)})
						</TabsTrigger>
						{decks.map((deck) => {
							const deckData = filteredData.find((item) => item.deck.id === deck.id);
							const count = deckData?.flashcards.length || 0;
							if (count === 0 && searchQuery) return null;
							return (
								<TabsTrigger key={deck.id} value={deck.id}>
									{deck.name} ({count})
								</TabsTrigger>
							);
						})}
					</TabsList>

					<TabsContent value="all" className="space-y-4">
						{filteredData.length === 0 ? (
							<Card>
								<CardContent className="py-12 text-center">
									<p className="text-muted-foreground">No flashcards match your search</p>
								</CardContent>
							</Card>
						) : (
							filteredData.map((item) => (
								<div key={item.deck.id} className="space-y-4">
									<div className="flex items-center justify-between">
										<div className="flex items-center gap-2">
											<BookOpen className="w-5 h-5 text-muted-foreground" />
											<h3 className="text-lg font-semibold">{item.deck.name}</h3>
											<Badge variant="secondary">{item.flashcards.length} cards</Badge>
										</div>
										<Button
											size="sm"
											onClick={() => onStartReview(item.deck.id)}
											className="gap-2"
										>
											<Play className="w-3 h-3" />
											Review
										</Button>
									</div>
									<div className="grid gap-3 md:grid-cols-2">
										{item.flashcards.map((card) => (
											<FlashcardPreview key={card.id} card={card} />
										))}
									</div>
								</div>
							))
						)}
					</TabsContent>

					{decks.map((deck) => {
						const deckData = filteredData.find((item) => item.deck.id === deck.id);
						if (!deckData || deckData.flashcards.length === 0) return null;

						return (
							<TabsContent key={deck.id} value={deck.id} className="space-y-4">
								<div className="flex items-center justify-between mb-4">
									<div className="flex items-center gap-2">
										<h3 className="text-lg font-semibold">{deck.name}</h3>
										<Badge variant="secondary">{deckData.flashcards.length} cards</Badge>
									</div>
									<Button
										size="sm"
										onClick={() => onStartReview(deck.id)}
										className="gap-2"
									>
										<Play className="w-3 h-3" />
										Review Deck
									</Button>
								</div>
								<div className="grid gap-3 md:grid-cols-2">
									{deckData.flashcards.map((card) => (
										<FlashcardPreview key={card.id} card={card} />
									))}
								</div>
							</TabsContent>
						);
					})}
				</Tabs>
			)}
		</div>
	);
}

interface FlashcardPreviewProps {
	card: {
		id: string;
		question: string;
		answer: string;
	};
}

function FlashcardPreview({ card }: FlashcardPreviewProps) {
	const [isFlipped, setIsFlipped] = useState(false);

	return (
		<Card
			className="cursor-pointer hover:shadow-md transition-all"
			onClick={() => setIsFlipped(!isFlipped)}
		>
			<CardHeader className="pb-3">
				<div className="text-xs text-muted-foreground font-medium mb-1">
					{isFlipped ? "Answer" : "Question"}
				</div>
				<CardTitle className="text-base font-medium leading-snug">
					{isFlipped ? card.answer : card.question}
				</CardTitle>
			</CardHeader>
			<CardContent className="pt-0">
				<p className="text-xs text-muted-foreground">Click to flip</p>
			</CardContent>
		</Card>
	);
}
