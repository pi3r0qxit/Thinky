import { useLocalAuth } from "@/contexts/LocalAuthContext";
import { useDecks, useUsageStats } from "@/hooks/useAppData";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/contexts/ThemeContext";
import { Badge } from "@/components/ui/badge";
import { User, Moon, Sun, Crown, LogOut, Sparkles } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface ProfilePageProps {
	isPremium: boolean;
}

export function ProfilePage({ isPremium }: ProfilePageProps) {
	const { user, logout } = useLocalAuth();
	const { theme, toggleTheme } = useTheme();
	const { data: decks = [] } = useDecks();
	const stats = useUsageStats(isPremium);

	const totalFlashcards = 0; // Would need to aggregate from all decks

	return (
		<div className="container mx-auto px-4 py-8 max-w-4xl">
			<div className="mb-8">
				<h1 className="text-3xl font-bold mb-2">Profile & Settings</h1>
				<p className="text-muted-foreground">Manage your account and preferences</p>
			</div>

			<div className="space-y-6">
				<Card>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<User className="w-5 h-5" />
							Account Status
						</CardTitle>
					</CardHeader>
					<CardContent className="space-y-4">
						<div className="flex items-center justify-between">
							<span className="text-sm font-medium">Name</span>
							<span className="text-sm text-muted-foreground">{user?.name}</span>
						</div>
						<Separator />
						<div className="flex items-center justify-between">
							<span className="text-sm font-medium">Email</span>
							<span className="text-sm text-muted-foreground">{user?.email}</span>
						</div>
						<Separator />
						<div className="flex items-center justify-between">
							<span className="text-sm font-medium">Total Decks</span>
							<span className="text-sm text-muted-foreground">{decks.length}</span>
						</div>
					</CardContent>
				</Card>

				<Card>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<Sparkles className="w-5 h-5" />
							Usage Statistics
						</CardTitle>
						<CardDescription>Track your flashcard generation activity</CardDescription>
					</CardHeader>
					<CardContent className="space-y-4">
						<div className="flex items-center justify-between">
							<span className="text-sm font-medium">Generated Today</span>
							<span className="text-sm text-muted-foreground">
								{stats.generatedToday} cards
							</span>
						</div>
						<Separator />
						<div className="flex items-center justify-between">
							<span className="text-sm font-medium">Daily Limit</span>
							<span className="text-sm text-muted-foreground font-semibold text-green-600 dark:text-green-400">
								Unlimited ✨
							</span>
						</div>
					</CardContent>
				</Card>

				<Card>
					<CardHeader>
						<CardTitle>Appearance</CardTitle>
						<CardDescription>Customize your visual experience</CardDescription>
					</CardHeader>
					<CardContent>
						<div className="flex items-center justify-between">
							<span className="text-sm font-medium">Theme</span>
							<Button variant="outline" size="sm" onClick={toggleTheme} className="gap-2">
								{theme === "dark" ? (
									<>
										<Sun className="w-4 h-4" />
										Light Mode
									</>
								) : (
									<>
										<Moon className="w-4 h-4" />
										Dark Mode
									</>
								)}
							</Button>
						</div>
					</CardContent>
				</Card>

				<Card className="border-destructive/50">
					<CardHeader>
						<CardTitle className="text-destructive">Account Actions</CardTitle>
					</CardHeader>
					<CardContent>
						<Button
							variant="destructive"
							onClick={() => logout()}
							className="gap-2"
						>
							<LogOut className="w-4 h-4" />
							Sign Out
						</Button>
					</CardContent>
				</Card>
			</div>
		</div>
	);
}
