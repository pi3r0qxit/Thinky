import { useState } from "react";
import { useDecks, useDeleteDeck, useUpdateDeck, useFlashcards } from "@/hooks/useAppData";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BookOpen, Trash2, Edit2, Play } from "lucide-react";
import {
	AlertDialog,
	AlertDialogAction,
	AlertDialogCancel,
	AlertDialogContent,
	AlertDialogDescription,
	AlertDialogFooter,
	AlertDialogHeader,
	AlertDialogTitle,
	AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
	DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

interface DecksPageProps {
	onStartReview: (deckId: string) => void;
}

export function DecksPage({ onStartReview }: DecksPageProps) {
	const { data: decks = [], isLoading } = useDecks();
	const deleteDeck = useDeleteDeck();
	const updateDeck = useUpdateDeck();

	const [editingDeck, setEditingDeck] = useState<{ id: string; name: string } | null>(null);
	const [editName, setEditName] = useState("");

	const handleDelete = async (deckId: string, deckName: string) => {
		try {
			await deleteDeck.mutateAsync(deckId);
			toast.success(`Deleted "${deckName}"`);
		} catch (error) {
			toast.error("Failed to delete deck");
		}
	};

	const handleRename = async () => {
		if (!editingDeck || !editName.trim()) return;

		try {
			await updateDeck.mutateAsync({
				id: editingDeck.id,
				name: editName.trim(),
			});
			toast.success("Deck renamed successfully");
			setEditingDeck(null);
			setEditName("");
		} catch (error) {
			toast.error("Failed to rename deck");
		}
	};

	return (
		<div className="container mx-auto px-4 py-8 max-w-6xl">
			<div className="mb-8">
				<h1 className="text-3xl font-bold mb-2">My Decks</h1>
				<p className="text-muted-foreground">
					Manage and review your flashcard collections
				</p>
			</div>

			{isLoading ? (
				<div className="text-center py-12">
					<div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
					<p className="text-muted-foreground">Loading decks...</p>
				</div>
			) : decks.length === 0 ? (
				<Card>
					<CardContent className="py-16 text-center">
						<BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
						<h3 className="text-xl font-semibold mb-2">No decks yet</h3>
						<p className="text-muted-foreground mb-6">
							Start by generating your first set of flashcards
						</p>
					</CardContent>
				</Card>
			) : (
				<div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
					{decks.map((deck) => (
						<DeckCard
							key={deck.id}
							deck={deck}
							onStartReview={onStartReview}
							onDelete={handleDelete}
							onRename={(id, name) => {
								setEditingDeck({ id, name });
								setEditName(name);
							}}
						/>
					))}
				</div>
			)}

			<Dialog open={!!editingDeck} onOpenChange={(open) => !open && setEditingDeck(null)}>
				<DialogContent>
					<DialogHeader>
						<DialogTitle>Rename Deck</DialogTitle>
						<DialogDescription>Enter a new name for your deck</DialogDescription>
					</DialogHeader>
					<div className="py-4">
						<Label htmlFor="deck-name">Deck Name</Label>
						<Input
							id="deck-name"
							value={editName}
							onChange={(e) => setEditName(e.target.value)}
							placeholder="Enter deck name..."
						/>
					</div>
					<DialogFooter>
						<Button variant="outline" onClick={() => setEditingDeck(null)}>
							Cancel
						</Button>
						<Button onClick={handleRename}>Save</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</div>
	);
}

interface DeckCardProps {
	deck: { id: string; name: string; update_time: string };
	onStartReview: (deckId: string) => void;
	onDelete: (deckId: string, deckName: string) => void;
	onRename: (deckId: string, deckName: string) => void;
}

function DeckCard({ deck, onStartReview, onDelete, onRename }: DeckCardProps) {
	const { data: flashcards = [] } = useFlashcards(deck.id);

	return (
		<Card className="hover:shadow-lg transition-shadow">
			<CardHeader>
				<CardTitle className="flex items-center gap-2">
					<BookOpen className="w-5 h-5" />
					{deck.name}
				</CardTitle>
				<CardDescription>
					{flashcards.length} cards • Updated{" "}
					{new Date(parseInt(deck.update_time) * 1000).toLocaleDateString()}
				</CardDescription>
			</CardHeader>
			<CardContent className="space-y-2">
				<Button
					className="w-full gap-2"
					onClick={() => onStartReview(deck.id)}
					disabled={flashcards.length === 0}
				>
					<Play className="w-4 h-4" />
					Start Review
				</Button>
				<div className="flex gap-2">
					<Dialog>
						<DialogTrigger asChild>
							<Button variant="outline" className="flex-1 gap-2">
								<Edit2 className="w-4 h-4" />
								Rename
							</Button>
						</DialogTrigger>
					</Dialog>

					<AlertDialog>
						<AlertDialogTrigger asChild>
							<Button variant="outline" className="flex-1 gap-2 text-destructive">
								<Trash2 className="w-4 h-4" />
								Delete
							</Button>
						</AlertDialogTrigger>
						<AlertDialogContent>
							<AlertDialogHeader>
								<AlertDialogTitle>Delete Deck</AlertDialogTitle>
								<AlertDialogDescription>
									Are you sure you want to delete "{deck.name}"? This will also delete all {flashcards.length} flashcards in this deck. This action cannot be undone.
								</AlertDialogDescription>
							</AlertDialogHeader>
							<AlertDialogFooter>
								<AlertDialogCancel>Cancel</AlertDialogCancel>
								<AlertDialogAction onClick={() => onDelete(deck.id, deck.name)}>
									Delete
								</AlertDialogAction>
							</AlertDialogFooter>
						</AlertDialogContent>
					</AlertDialog>

					<Button
						variant="ghost"
						size="icon"
						onClick={() => onRename(deck.id, deck.name)}
					>
						<Edit2 className="w-4 h-4" />
					</Button>
				</div>
			</CardContent>
		</Card>
	);
}
