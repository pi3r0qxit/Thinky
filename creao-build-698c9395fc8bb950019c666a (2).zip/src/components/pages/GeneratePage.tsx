import { useState } from "react";
import { useCreateDeck, useCreateFlashcards, useDecks, useUsageStats } from "@/hooks/useAppData";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { FileText, Image, Upload, Sparkles, Crown, Loader2 } from "lucide-react";
import { requestCreaoFileUpload } from "@/sdk/api-clients/68b68b97ac476c8df7efbeaf/requestCreaoFileUpload";
import { requestOpenAIGPTVision } from "@/sdk/api-clients/68a5655cdeb2a0b2f64c013d/requestOpenAIGPTVision";
import { requestOpenAIGPTChat } from "@/sdk/api-clients/688a0b64dc79a2533460892c/requestOpenAIGPTChat";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TestAPIButton } from "@/components/TestAPIButton";

type Page = "dashboard" | "generate" | "decks" | "review" | "profile" | "premium";

interface GeneratePageProps {
	isPremium: boolean;
	onNavigate: (page: Page) => void;
}

export function GeneratePage({ isPremium, onNavigate }: GeneratePageProps) {
	const [text, setText] = useState("");
	const [selectedFile, setSelectedFile] = useState<File | null>(null);
	const [deckName, setDeckName] = useState("");
	const [selectedDeckId, setSelectedDeckId] = useState<string>("");
	const [isGenerating, setIsGenerating] = useState(false);

	const { data: decks = [] } = useDecks();
	const createDeck = useCreateDeck();
	const createFlashcards = useCreateFlashcards();
	const stats = useUsageStats(isPremium);

	const handleTextGenerate = async () => {
		if (!text.trim()) {
			toast.error("Please enter some text to generate flashcards");
			return;
		}

		let targetDeckId = selectedDeckId;
		if (!targetDeckId && deckName.trim()) {
			try {
				const newDeck = await createDeck.mutateAsync(deckName.trim());
				targetDeckId = newDeck.id;
			} catch (error) {
				toast.error("Failed to create deck");
				return;
			}
		}

		if (!targetDeckId) {
			toast.error("Please select a deck or create a new one");
			return;
		}

		setIsGenerating(true);

		try {
			const prompt = `Generate flashcards from the following study material. Each flashcard should have:
1. A clear question that tests understanding (not just memorization)
2. A concise answer (1-2 sentences maximum)

Return ONLY a valid JSON array of objects with "question" and "answer" fields. No additional text or formatting.

Study Material:
${text}

Format: [{"question": "...", "answer": "..."}, ...]`;

			console.log("Sending request to OpenAI...");
			const response = await requestOpenAIGPTChat({
				body: {
					model: "gpt-4o-mini",
					messages: [{ role: "user", content: prompt }],
				},
			});

			console.log("Response received:", response);

			let flashcards: Array<{ question: string; answer: string }> = [];

			try {
				if (!response.data) {
					console.error("No response data");
					throw new Error("No response data from API");
				}
				console.log("Response data:", response.data);
				const content = response.data.choices[0].message.content;
				console.log("Content to parse:", content);

				// Clean up the content before parsing
				let cleanContent = content.trim();
				// Remove markdown code blocks if present
				cleanContent = cleanContent.replace(/```json\n?/g, "").replace(/```\n?/g, "");

				flashcards = JSON.parse(cleanContent);
				console.log("Parsed flashcards:", flashcards);
			} catch (parseError) {
				console.error("Parse error:", parseError);
				toast.error(`Failed to parse AI response: ${parseError instanceof Error ? parseError.message : 'Unknown error'}`);
				setIsGenerating(false);
				return;
			}

			if (!Array.isArray(flashcards) || flashcards.length === 0) {
				console.error("No flashcards in array:", flashcards);
				toast.error("No flashcards generated. Please try with different content.");
				setIsGenerating(false);
				return;
			}

			console.log("Creating flashcards in database...");
			await createFlashcards.mutateAsync({
				deckId: targetDeckId,
				flashcards,
			});

			toast.success(`Generated ${flashcards.length} flashcards successfully!`);
			setText("");
			setDeckName("");
		} catch (error) {
			console.error("Generation error:", error);
			toast.error(`Failed to generate flashcards: ${error instanceof Error ? error.message : 'Unknown error'}`);
		} finally {
			setIsGenerating(false);
		}
	};

	const handleFileUpload = async (file: File) => {
		let targetDeckId = selectedDeckId;
		if (!targetDeckId && deckName.trim()) {
			try {
				const newDeck = await createDeck.mutateAsync(deckName.trim());
				targetDeckId = newDeck.id;
			} catch (error) {
				toast.error("Failed to create deck");
				return;
			}
		}

		if (!targetDeckId) {
			toast.error("Please select a deck or create a new one");
			return;
		}

		setIsGenerating(true);

		try {
			const uploadResult = await requestCreaoFileUpload({
				body: {
					fileName: file.name,
					contentType: file.type,
				},
			});

			if (!uploadResult.data?.presignedUrl || !uploadResult.data?.realFileUrl) {
				throw new Error("Failed to get upload URL");
			}

			// Upload file to S3
			await fetch(uploadResult.data.presignedUrl, {
				method: "PUT",
				headers: {
					"Content-Type": file.type,
				},
				body: file,
			});

			const fileUrl = uploadResult.data.realFileUrl;
			let extractedText = "";

			if (file.type.startsWith("image/")) {
				const visionResult = await requestOpenAIGPTVision({
					body: {
						messages: [
							{
								role: "user",
								content: [
									{ type: "text", text: "Extract all text from this image." },
									{ type: "image_url", image_url: { url: fileUrl } },
								],
							},
						],
					},
				});
				if (!visionResult.data) throw new Error("No vision response");
				extractedText = visionResult.data.choices[0].message.content;
			} else {
				toast.error("PDF text extraction not yet implemented. Please use text or image input.");
				setIsGenerating(false);
				return;
			}

			const prompt = `Generate flashcards from this text. Return ONLY a JSON array of objects with "question" and "answer" fields.

Text:
${extractedText}

Format: [{"question": "...", "answer": "..."}, ...]`;

			console.log("Sending OCR text to OpenAI...");
			const response = await requestOpenAIGPTChat({
				body: {
					model: "gpt-4o-mini",
					messages: [{ role: "user", content: prompt }],
				},
			});

			console.log("Response from file:", response);

			if (!response.data) throw new Error("No response data");
			const content = response.data.choices[0].message.content;
			console.log("File content to parse:", content);

			// Clean up the content before parsing
			let cleanContent = content.trim();
			cleanContent = cleanContent.replace(/```json\n?/g, "").replace(/```\n?/g, "");

			const flashcards = JSON.parse(cleanContent);
			console.log("Parsed flashcards from file:", flashcards);

			await createFlashcards.mutateAsync({
				deckId: targetDeckId,
				flashcards,
			});

			toast.success(`Generated ${flashcards.length} flashcards from ${file.name}!`);
			setSelectedFile(null);
			setDeckName("");
		} catch (error) {
			console.error("File upload error:", error);
			toast.error(`Failed to process file: ${error instanceof Error ? error.message : 'Unknown error'}`);
		} finally {
			setIsGenerating(false);
		}
	};

	return (
		<div className="container mx-auto px-4 py-8 max-w-4xl">
			<div className="mb-8">
				<div className="flex items-center justify-between">
					<div>
						<h1 className="text-3xl font-bold mb-2">Generate Flashcards</h1>
						<p className="text-muted-foreground">
							Transform your study materials into effective flashcards - completely free, unlimited!
						</p>
					</div>
					<TestAPIButton />
				</div>
			</div>

			<Card className="mb-6">
				<CardHeader>
					<CardTitle>Deck Selection</CardTitle>
					<CardDescription>Choose an existing deck or create a new one</CardDescription>
				</CardHeader>
				<CardContent className="space-y-4">
					<div>
						<Label>Select Existing Deck</Label>
						<Select value={selectedDeckId} onValueChange={setSelectedDeckId}>
							<SelectTrigger>
								<SelectValue placeholder="Choose a deck..." />
							</SelectTrigger>
							<SelectContent>
								{decks.map((deck) => (
									<SelectItem key={deck.id} value={deck.id}>
										{deck.name}
									</SelectItem>
								))}
							</SelectContent>
						</Select>
					</div>

					<div className="text-center text-sm text-muted-foreground">OR</div>

					<div>
						<Label htmlFor="deckName">Create New Deck</Label>
						<Input
							id="deckName"
							placeholder="Enter deck name..."
							value={deckName}
							onChange={(e) => {
								setDeckName(e.target.value);
								setSelectedDeckId("");
							}}
						/>
					</div>
				</CardContent>
			</Card>

			<Tabs defaultValue="text" className="space-y-6">
				<TabsList className="grid w-full grid-cols-2">
					<TabsTrigger value="text" className="gap-2">
						<FileText className="w-4 h-4" />
						Text Input
					</TabsTrigger>
					<TabsTrigger value="upload" className="gap-2">
						<Upload className="w-4 h-4" />
						File Upload
					</TabsTrigger>
				</TabsList>

				<TabsContent value="text">
					<Card>
						<CardHeader>
							<CardTitle>Paste Your Study Material</CardTitle>
							<CardDescription>
								Enter text from notes, textbooks, or any study material
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-4">
							<Textarea
								placeholder="Paste your study material here..."
								className="min-h-[300px]"
								value={text}
								onChange={(e) => setText(e.target.value)}
							/>
							<Button
								className="w-full gap-2"
								onClick={handleTextGenerate}
								disabled={isGenerating}
							>
								{isGenerating ? (
									<>
										<Loader2 className="w-4 h-4 animate-spin" />
										Generating...
									</>
								) : (
									<>
										<Sparkles className="w-4 h-4" />
										Generate Flashcards
									</>
								)}
							</Button>
						</CardContent>
					</Card>
				</TabsContent>

				<TabsContent value="upload">
					<Card>
						<CardHeader>
							<CardTitle>Upload Files</CardTitle>
							<CardDescription>
								Upload images (with OCR) or PDF documents
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-4">
							<div className="border-2 border-dashed rounded-lg p-12 text-center">
								<input
									type="file"
									id="file-upload"
									className="hidden"
									accept="image/*,application/pdf"
									onChange={(e) => {
										const file = e.target.files?.[0];
										if (file) {
											setSelectedFile(file);
										}
									}}
								/>
								<label htmlFor="file-upload" className="cursor-pointer">
									<Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
									<p className="font-medium mb-2">
										{selectedFile ? selectedFile.name : "Click to upload"}
									</p>
									<p className="text-sm text-muted-foreground">
										Supports: Images (JPG, PNG) and PDF files
									</p>
								</label>
							</div>

							{selectedFile && (
								<Button
									className="w-full gap-2"
									onClick={() => handleFileUpload(selectedFile)}
									disabled={isGenerating}
								>
									{isGenerating ? (
										<>
											<Loader2 className="w-4 h-4 animate-spin" />
											Processing...
										</>
									) : (
										<>
											<Sparkles className="w-4 h-4" />
											Generate from File
										</>
									)}
								</Button>
							)}
						</CardContent>
					</Card>
				</TabsContent>
			</Tabs>
		</div>
	);
}
