import { useState } from "react";
import { useFlashcards, useDecks } from "@/hooks/useAppData";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, RotateCcw, ChevronLeft, ChevronRight } from "lucide-react";

interface ReviewPageProps {
	deckId: string;
	onExit: () => void;
}

export function ReviewPage({ deckId, onExit }: ReviewPageProps) {
	const { data: flashcards = [], isLoading } = useFlashcards(deckId);
	const { data: decks = [] } = useDecks();
	const [currentIndex, setCurrentIndex] = useState(0);
	const [isFlipped, setIsFlipped] = useState(false);

	const deck = decks.find((d) => d.id === deckId);
	const currentCard = flashcards[currentIndex];

	const handleNext = () => {
		if (currentIndex < flashcards.length - 1) {
			setCurrentIndex(currentIndex + 1);
			setIsFlipped(false);
		}
	};

	const handlePrevious = () => {
		if (currentIndex > 0) {
			setCurrentIndex(currentIndex - 1);
			setIsFlipped(false);
		}
	};

	const handleReset = () => {
		setCurrentIndex(0);
		setIsFlipped(false);
	};

	if (isLoading) {
		return (
			<div className="flex items-center justify-center min-h-[60vh]">
				<div className="text-center">
					<div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
					<p className="text-muted-foreground">Loading flashcards...</p>
				</div>
			</div>
		);
	}

	if (flashcards.length === 0) {
		return (
			<div className="container mx-auto px-4 py-8 max-w-4xl">
				<Button variant="ghost" onClick={onExit} className="mb-6 gap-2">
					<ArrowLeft className="w-4 h-4" />
					Back to Decks
				</Button>
				<Card>
					<CardContent className="py-16 text-center">
						<p className="text-xl text-muted-foreground">
							This deck has no flashcards yet
						</p>
					</CardContent>
				</Card>
			</div>
		);
	}

	const progress = ((currentIndex + 1) / flashcards.length) * 100;

	return (
		<div className="container mx-auto px-4 py-8 max-w-4xl">
			<div className="flex items-center justify-between mb-6">
				<Button variant="ghost" onClick={onExit} className="gap-2">
					<ArrowLeft className="w-4 h-4" />
					Back to Decks
				</Button>
				<Button variant="outline" onClick={handleReset} className="gap-2">
					<RotateCcw className="w-4 h-4" />
					Reset
				</Button>
			</div>

			<div className="mb-8">
				<div className="flex items-center justify-between mb-2">
					<h1 className="text-2xl font-bold">{deck?.name}</h1>
					<span className="text-muted-foreground">
						{currentIndex + 1} / {flashcards.length}
					</span>
				</div>
				<Progress value={progress} className="h-2" />
			</div>

			<div className="mb-8">
				<Card
					className="cursor-pointer hover:shadow-lg transition-all duration-300 min-h-[400px]"
					onClick={() => setIsFlipped(!isFlipped)}
				>
					<CardContent className="flex items-center justify-center p-12 min-h-[400px]">
						<div className="text-center max-w-2xl">
							{!isFlipped ? (
								<div>
									<p className="text-sm text-muted-foreground mb-4">Question</p>
									<p className="text-2xl font-medium">{currentCard.question}</p>
									<p className="text-sm text-muted-foreground mt-8">
										Click to reveal answer
									</p>
								</div>
							) : (
								<div>
									<p className="text-sm text-muted-foreground mb-4">Answer</p>
									<p className="text-xl">{currentCard.answer}</p>
									<p className="text-sm text-muted-foreground mt-8">
										Click to see question
									</p>
								</div>
							)}
						</div>
					</CardContent>
				</Card>
			</div>

			<div className="flex items-center justify-between">
				<Button
					variant="outline"
					onClick={handlePrevious}
					disabled={currentIndex === 0}
					className="gap-2"
				>
					<ChevronLeft className="w-4 h-4" />
					Previous
				</Button>

				<Button
					onClick={() => setIsFlipped(!isFlipped)}
					variant="secondary"
				>
					{isFlipped ? "Show Question" : "Show Answer"}
				</Button>

				<Button
					variant="outline"
					onClick={handleNext}
					disabled={currentIndex === flashcards.length - 1}
					className="gap-2"
				>
					Next
					<ChevronRight className="w-4 h-4" />
				</Button>
			</div>
		</div>
	);
}
