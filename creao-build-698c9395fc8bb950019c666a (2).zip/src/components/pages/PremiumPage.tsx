import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Zap, Shield, Heart, Check } from "lucide-react";

export function PremiumPage() {
	const features = [
		{
			icon: Sparkles,
			title: "Unlimited Generation",
			description: "Generate as many flashcards as you need, completely free",
		},
		{
			icon: Zap,
			title: "All Input Types",
			description: "Text, images, and PDF support - all available to everyone",
		},
		{
			icon: Shield,
			title: "Full Features",
			description: "Access to all features without any restrictions",
		},
	];

	return (
		<div className="container mx-auto px-4 py-8 max-w-4xl">
			<div className="text-center mb-12">
				<div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
					<Heart className="w-10 h-10" />
				</div>
				<h1 className="text-4xl font-bold mb-3">Everything is Free!</h1>
				<p className="text-xl text-muted-foreground">
					All features are available to everyone, forever
				</p>
			</div>

			<div className="grid gap-8 md:grid-cols-3 mb-12">
				{features.map((feature, index) => (
					<Card key={index} className="text-center">
						<CardHeader>
							<div className="bg-primary/10 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
								<feature.icon className="w-6 h-6 text-primary" />
							</div>
							<CardTitle className="text-lg">{feature.title}</CardTitle>
							<CardDescription>{feature.description}</CardDescription>
						</CardHeader>
					</Card>
				))}
			</div>

			<Card className="max-w-md mx-auto border-2 border-green-500">
				<CardHeader className="text-center">
					<div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white text-sm font-semibold px-3 py-1 rounded-full w-fit mx-auto mb-2">
						100% Free
					</div>
					<CardTitle className="text-3xl">Free Forever</CardTitle>
					<CardDescription>
						<span className="text-4xl font-bold text-foreground">$0</span>
						<span className="text-muted-foreground">/month</span>
					</CardDescription>
				</CardHeader>
				<CardContent className="space-y-6">
					<div className="space-y-3">
						<div className="flex items-center gap-3">
							<div className="bg-green-100 dark:bg-green-900 rounded-full p-1">
								<Check className="w-4 h-4 text-green-600 dark:text-green-400" />
							</div>
							<span className="text-sm">Unlimited flashcard generation</span>
						</div>
						<div className="flex items-center gap-3">
							<div className="bg-green-100 dark:bg-green-900 rounded-full p-1">
								<Check className="w-4 h-4 text-green-600 dark:text-green-400" />
							</div>
							<span className="text-sm">All input types (text, images, PDFs)</span>
						</div>
						<div className="flex items-center gap-3">
							<div className="bg-green-100 dark:bg-green-900 rounded-full p-1">
								<Check className="w-4 h-4 text-green-600 dark:text-green-400" />
							</div>
							<span className="text-sm">Unlimited decks</span>
						</div>
						<div className="flex items-center gap-3">
							<div className="bg-green-100 dark:bg-green-900 rounded-full p-1">
								<Check className="w-4 h-4 text-green-600 dark:text-green-400" />
							</div>
							<span className="text-sm">Full review features</span>
						</div>
						<div className="flex items-center gap-3">
							<div className="bg-green-100 dark:bg-green-900 rounded-full p-1">
								<Check className="w-4 h-4 text-green-600 dark:text-green-400" />
							</div>
							<span className="text-sm">No ads, no limits, no credit card</span>
						</div>
					</div>

					<div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-900 rounded-lg p-4 text-center">
						<p className="text-sm font-medium text-green-800 dark:text-green-200">
							You already have access to everything! 🎉
						</p>
						<p className="text-xs text-green-600 dark:text-green-400 mt-2">
							Start creating flashcards and enjoy unlimited learning
						</p>
					</div>
				</CardContent>
			</Card>

			<div className="mt-12 text-center">
				<h3 className="text-lg font-semibold mb-4">Our Mission</h3>
				<p className="text-muted-foreground max-w-2xl mx-auto">
					We believe that education should be accessible to everyone. That's why Thinky is
					completely free, with no hidden costs or premium tiers. Focus on learning, not on
					subscriptions.
				</p>
			</div>
		</div>
	);
}
