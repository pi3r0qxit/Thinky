import { useState } from "react";
import { Button } from "@/components/ui/button";
import { requestOpenAIGPTChat } from "@/sdk/api-clients/688a0b64dc79a2533460892c/requestOpenAIGPTChat";
import { toast } from "sonner";

export function TestAPIButton() {
	const [testing, setTesting] = useState(false);

	const testAPI = async () => {
		setTesting(true);
		try {
			console.log("Testing OpenAI API...");
			const response = await requestOpenAIGPTChat({
				body: {
					model: "gpt-4o-mini",
					messages: [
						{ role: "user", content: "Say 'API is working!' and nothing else." },
					],
				},
			});

			console.log("Full API response:", response);

			if (response.error) {
				console.error("API Error:", response.error);
				toast.error(`API Error: ${JSON.stringify(response.error)}`);
				return;
			}

			if (response.data) {
				console.log("API Success:", response.data);
				toast.success(`API Response: ${response.data.choices[0].message.content}`);
			} else {
				console.error("No data in response");
				toast.error("No data in API response");
			}
		} catch (error) {
			console.error("Test error:", error);
			toast.error(`Error: ${error instanceof Error ? error.message : "Unknown error"}`);
		} finally {
			setTesting(false);
		}
	};

	return (
		<Button onClick={testAPI} disabled={testing} variant="outline" size="sm">
			{testing ? "Testing..." : "Test API"}
		</Button>
	);
}
