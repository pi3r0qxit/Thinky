import { Button } from "@/components/ui/button";
import { useTheme } from "@/contexts/ThemeContext";
import {
	Home,
	Sparkles,
	BookOpen,
	User,
	Crown,
	Moon,
	Sun,
	GraduationCap,
	Menu,
	Library,
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { DiagnosticPanel } from "@/components/DiagnosticPanel";

type Page = "dashboard" | "generate" | "decks" | "flashcards" | "review" | "profile" | "premium";

interface AppNavProps {
	currentPage: Page;
	onNavigate: (page: Page) => void;
	isPremium: boolean;
}

export function AppNav({ currentPage, onNavigate, isPremium }: AppNavProps) {
	const { theme, toggleTheme } = useTheme();

	const navItems = [
		{ id: "dashboard" as Page, label: "Dashboard", icon: Home },
		{ id: "generate" as Page, label: "Generate", icon: Sparkles },
		{ id: "flashcards" as Page, label: "Flashcards", icon: Library },
		{ id: "decks" as Page, label: "My Decks", icon: BookOpen },
		{ id: "profile" as Page, label: "Profile", icon: User },
	];

	return (
		<nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
			<div className="container mx-auto px-4">
				<div className="flex items-center justify-between h-16">
					{/* Logo */}
					<div className="flex items-center gap-2">
						<div className="bg-black text-white rounded-full w-10 h-10 flex items-center justify-center">
							<GraduationCap className="w-6 h-6" />
						</div>
						<span className="text-xl font-bold hidden sm:inline">Thinky</span>
					</div>

					{/* Desktop Navigation */}
					<div className="hidden md:flex items-center gap-2">
						{navItems.map((item) => (
							<Button
								key={item.id}
								variant={currentPage === item.id ? "default" : "ghost"}
								onClick={() => onNavigate(item.id)}
								className="gap-2"
							>
								<item.icon className="w-4 h-4" />
								{item.label}
							</Button>
						))}
					</div>

					{/* Right Side Actions */}
					<div className="flex items-center gap-2">
						<DiagnosticPanel />

						<Button variant="ghost" size="icon" onClick={toggleTheme}>
							{theme === "dark" ? (
								<Sun className="w-5 h-5" />
							) : (
								<Moon className="w-5 h-5" />
							)}
						</Button>

						{/* Mobile Menu */}
						<Sheet>
							<SheetTrigger asChild className="md:hidden">
								<Button variant="ghost" size="icon">
									<Menu className="w-5 h-5" />
								</Button>
							</SheetTrigger>
							<SheetContent>
								<div className="flex flex-col gap-4 mt-8">
									{navItems.map((item) => (
										<Button
											key={item.id}
											variant={currentPage === item.id ? "default" : "ghost"}
											onClick={() => onNavigate(item.id)}
											className="justify-start gap-2"
										>
											<item.icon className="w-4 h-4" />
											{item.label}
										</Button>
									))}
								</div>
							</SheetContent>
						</Sheet>
					</div>
				</div>
			</div>
		</nav>
	);
}
