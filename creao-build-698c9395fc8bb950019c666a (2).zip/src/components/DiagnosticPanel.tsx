import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useDecks } from "@/hooks/useAppData";
import { getLocalUserId } from "@/contexts/LocalAuthContext";
import { Bug, RefreshCw } from "lucide-react";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogHeader,
	DialogTitle,
	DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useQuery } from "@tanstack/react-query";
import { FlashcardORM } from "@/sdk/database/orm/orm_flashcard";

export function DiagnosticPanel() {
	const [isOpen, setIsOpen] = useState(false);
	const { data: decks = [], refetch: refetchDecks } = useDecks();
	const userId = getLocalUserId();

	// Fetch all flashcards in a single query
	const { data: allFlashcards = [], refetch: refetchFlashcards } = useQuery({
		queryKey: ["all-flashcards-diagnostic"],
		queryFn: async () => {
			const flashcardORM = FlashcardORM.getInstance();
			return await flashcardORM.getAllFlashcard();
		},
		enabled: isOpen, // Only fetch when dialog is open
	});

	// Group flashcards by deck using useMemo
	const allFlashcardsData = useMemo(() => {
		return decks.map((deck) => {
			const flashcards = allFlashcards.filter((card) => card.deck_id === deck.id);
			return { deck, flashcards };
		});
	}, [decks, allFlashcards]);

	const totalFlashcards = allFlashcards.length;

	const handleRefresh = async () => {
		console.log("🔄 Manually refreshing all data...");
		await Promise.all([refetchDecks(), refetchFlashcards()]);
		console.log("✅ Data refreshed");
	};

	return (
		<Dialog open={isOpen} onOpenChange={setIsOpen}>
			<DialogTrigger asChild>
				<Button variant="outline" size="sm" className="gap-2">
					<Bug className="w-4 h-4" />
					Debug Info
				</Button>
			</DialogTrigger>
			<DialogContent className="max-w-3xl max-h-[80vh]">
				<DialogHeader>
					<DialogTitle className="flex items-center gap-2">
						<Bug className="w-5 h-5" />
						Diagnostic Information
					</DialogTitle>
					<DialogDescription>
						View your database contents and debug flashcard issues
					</DialogDescription>
				</DialogHeader>

				<ScrollArea className="max-h-[60vh]">
					<div className="space-y-4 pr-4">
						{/* User Info */}
						<Card>
							<CardHeader>
								<CardTitle className="text-base">User Information</CardTitle>
							</CardHeader>
							<CardContent>
								<div className="space-y-2 text-sm">
									<div className="flex justify-between">
										<span className="font-medium">User ID:</span>
										<code className="text-xs bg-muted px-2 py-1 rounded">
											{userId || "Not logged in"}
										</code>
									</div>
									<div className="flex justify-between">
										<span className="font-medium">Total Decks:</span>
										<Badge>{decks.length}</Badge>
									</div>
									<div className="flex justify-between">
										<span className="font-medium">Total Flashcards:</span>
										<Badge>{totalFlashcards}</Badge>
									</div>
								</div>
							</CardContent>
						</Card>

						{/* Deck Details */}
						<Card>
							<CardHeader>
								<div className="flex items-center justify-between">
									<CardTitle className="text-base">Deck Details</CardTitle>
									<Button size="sm" variant="outline" onClick={handleRefresh}>
										<RefreshCw className="w-3 h-3 mr-2" />
										Refresh
									</Button>
								</div>
							</CardHeader>
							<CardContent>
								{decks.length === 0 ? (
									<p className="text-sm text-muted-foreground">No decks found</p>
								) : (
									<div className="space-y-3">
										{allFlashcardsData.map(({ deck, flashcards }) => (
											<div
												key={deck.id}
												className="border rounded-lg p-3 space-y-2"
											>
												<div className="flex items-center justify-between">
													<span className="font-medium">{deck.name}</span>
													<Badge variant="secondary">
														{flashcards.length} cards
													</Badge>
												</div>
												<div className="text-xs space-y-1">
													<div className="flex justify-between">
														<span className="text-muted-foreground">Deck ID:</span>
														<code className="bg-muted px-1 rounded">
															{deck.id.slice(0, 8)}...
														</code>
													</div>
													<div className="flex justify-between">
														<span className="text-muted-foreground">User ID:</span>
														<code className="bg-muted px-1 rounded">
															{deck.user_id?.slice(0, 8) || "missing"}...
														</code>
													</div>
													<div className="flex justify-between">
														<span className="text-muted-foreground">Created:</span>
														<span>
															{new Date(
																parseInt(deck.create_time) * 1000
															).toLocaleDateString()}
														</span>
													</div>
												</div>

												{flashcards.length > 0 && (
													<div className="mt-2 pt-2 border-t">
														<p className="text-xs font-medium mb-2">
															Sample Flashcards:
														</p>
														<div className="space-y-2">
															{flashcards.slice(0, 2).map((card) => (
																<div
																	key={card.id}
																	className="bg-muted/50 p-2 rounded text-xs"
																>
																	<div className="font-medium">
																		Q: {card.question.slice(0, 50)}
																		{card.question.length > 50 && "..."}
																	</div>
																	<div className="text-muted-foreground">
																		A: {card.answer.slice(0, 50)}
																		{card.answer.length > 50 && "..."}
																	</div>
																</div>
															))}
															{flashcards.length > 2 && (
																<p className="text-xs text-muted-foreground">
																	+ {flashcards.length - 2} more cards
																</p>
															)}
														</div>
													</div>
												)}
											</div>
										))}
									</div>
								)}
							</CardContent>
						</Card>

						{/* Browser Console Tip */}
						<Card className="border-amber-200 dark:border-amber-900">
							<CardHeader>
								<CardTitle className="text-base">Debugging Tips</CardTitle>
							</CardHeader>
							<CardContent className="space-y-2 text-sm">
								<p>1. Open browser console (F12) to see detailed logs</p>
								<p>2. Look for logs with emoji prefixes (🔄, ✅, ❌, etc.)</p>
								<p>3. Generate flashcards and watch the console for errors</p>
								<p>4. Check if flashcards are being inserted successfully</p>
								<p className="text-xs text-muted-foreground mt-4">
									All database operations are logged to help diagnose issues.
								</p>
							</CardContent>
						</Card>
					</div>
				</ScrollArea>
			</DialogContent>
		</Dialog>
	);
}
