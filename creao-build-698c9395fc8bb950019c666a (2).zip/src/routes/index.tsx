import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocalAuth } from "@/contexts/LocalAuthContext";
import { DashboardPage } from "@/components/pages/DashboardPage";
import { GeneratePage } from "@/components/pages/GeneratePage";
import { DecksPage } from "@/components/pages/DecksPage";
import { AllFlashcardsPage } from "@/components/pages/AllFlashcardsPage";
import { ReviewPage } from "@/components/pages/ReviewPage";
import { ProfilePage } from "@/components/pages/ProfilePage";
import { PremiumPage } from "@/components/pages/PremiumPage";
import { AppNav } from "@/components/AppNav";
import { LoginForm } from "@/components/auth/LoginForm";
import { RegisterForm } from "@/components/auth/RegisterForm";
import { GraduationCap } from "lucide-react";

export const Route = createFileRoute("/")({
	component: App,
});

type Page = "dashboard" | "generate" | "decks" | "flashcards" | "review" | "profile" | "premium";
type AuthView = "login" | "register";

function App() {
	const { user, isAuthenticated, isLoading } = useLocalAuth();
	const [currentPage, setCurrentPage] = useState<Page>("dashboard");
	const [selectedDeckId, setSelectedDeckId] = useState<string | null>(null);
	const [authView, setAuthView] = useState<AuthView>("login");

	// All features are now free for everyone!
	const isPremium = true;

	if (isLoading) {
		return (
			<div className="flex items-center justify-center min-h-screen">
				<div className="text-center">
					<div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
					<p className="text-muted-foreground">Loading...</p>
				</div>
			</div>
		);
	}

	if (!isAuthenticated) {
		return (
			<div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-background via-background to-muted/20 p-4">
				<div className="text-center max-w-md mx-auto w-full">
					<div className="bg-black text-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6 shadow-lg">
						<GraduationCap className="w-12 h-12" />
					</div>
					<h1 className="text-4xl font-bold mb-3">Thinky</h1>
					<p className="text-xl text-muted-foreground mb-8">
						AI-Powered Flashcard Generator
					</p>

					{authView === "login" ? (
						<LoginForm onSwitchToRegister={() => setAuthView("register")} />
					) : (
						<RegisterForm onSwitchToLogin={() => setAuthView("login")} />
					)}
				</div>
			</div>
		);
	}

	const handleStartReview = (deckId: string) => {
		setSelectedDeckId(deckId);
		setCurrentPage("review");
	};

	const handleExitReview = () => {
		setSelectedDeckId(null);
		setCurrentPage("decks");
	};

	return (
		<div className="min-h-screen flex flex-col">
			<AppNav
				currentPage={currentPage}
				onNavigate={setCurrentPage}
				isPremium={isPremium}
			/>

			<main className="flex-1">
				{currentPage === "dashboard" && (
					<DashboardPage
						onNavigate={setCurrentPage}
						onStartReview={handleStartReview}
						isPremium={isPremium}
					/>
				)}

				{currentPage === "generate" && (
					<GeneratePage isPremium={isPremium} onNavigate={setCurrentPage} />
				)}

				{currentPage === "flashcards" && (
					<AllFlashcardsPage onStartReview={handleStartReview} />
				)}

				{currentPage === "decks" && (
					<DecksPage onStartReview={handleStartReview} />
				)}

				{currentPage === "review" && selectedDeckId && (
					<ReviewPage deckId={selectedDeckId} onExit={handleExitReview} />
				)}

				{currentPage === "profile" && <ProfilePage isPremium={isPremium} />}

				{currentPage === "premium" && <PremiumPage />}
			</main>
		</div>
	);
}
